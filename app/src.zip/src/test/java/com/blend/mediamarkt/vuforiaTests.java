//package com.blend.mediamarkt;
//
//import android.test.suitebuilder.annotation.SmallTest;
//
//import org.junit.runner.RunWith;
//import org.powermock.modules.junit4.PowerMockRunner;
//import org.powermock.modules.junit4.;
//
//
///**
// * Created by geddy on 07/06/16.
// */
//
//@RunWith(PowerMockRunner.class)
//@SmallTest
//public class vuforiaTests {
//
//
//}
